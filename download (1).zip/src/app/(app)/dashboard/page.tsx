'use client';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, Leaf, TestTube2 } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { PageHeader, PageHeaderDescription, PageHeaderHeading } from '@/components/page-header';
import { useLanguage } from '@/context/language-context';
import { translations } from '@/lib/translations';

export default function DashboardPage() {
    const { language } = useLanguage();
    const t = translations[language].dashboard;

    const features = [
        {
          title: t.features[0].title,
          description: t.features[0].description,
          href: '/disease-detection',
          icon: Leaf,
          image: PlaceHolderImages.find(img => img.id === 'disease-detection-card'),
        },
        {
          title: t.features[1].title,
          description: t.features[1].description,
          href: '/soil-analysis',
          icon: TestTube2,
          image: PlaceHolderImages.find(img => img.id === 'soil-analysis-card'),
        },
      ];
      
      const heroImage = PlaceHolderImages.find(img => img.id === 'hero-image');

  return (
    <div className="container relative">
        <PageHeader>
            <PageHeaderHeading>{t.title}</PageHeaderHeading>
            <PageHeaderDescription>{t.description}</PageHeaderDescription>
        </PageHeader>
      
        <div className="relative w-full h-64 md:h-80 mb-12 rounded-lg overflow-hidden shadow-lg">
            {heroImage && (
                 <Image
                    src={heroImage.imageUrl}
                    alt={heroImage.description}
                    fill
                    className="object-cover"
                    data-ai-hint={heroImage.imageHint}
                />
            )}
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <h2 className="text-4xl md:text-5xl font-bold text-white text-center drop-shadow-md">
                    {t.hero}
                </h2>
            </div>
        </div>

      <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2">
        {features.map((feature) => (
          <Card key={feature.title} className="flex flex-col overflow-hidden transition-transform hover:scale-105 hover:shadow-xl">
            {feature.image && (
                <div className="aspect-video relative">
                    <Image
                        src={feature.image.imageUrl}
                        alt={feature.image.description}
                        fill
                        className="object-cover"
                        data-ai-hint={feature.image.imageHint}
                    />
                </div>
            )}
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-2xl">
                <feature.icon className="h-7 w-7 text-primary" />
                {feature.title}
              </CardTitle>
              <CardDescription>{feature.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow" />
            <CardFooter>
              <Button asChild className="w-full bg-primary hover:bg-primary/90">
                <Link href={feature.href}>
                  {t.getStarted} <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
