'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  BookOpen,
  Languages,
  LayoutDashboard,
  Leaf,
  TestTube2,
} from 'lucide-react';

import { cn } from '@/lib/utils';
import { AppLogo } from '@/components/app-logo';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { LanguageProvider, useLanguage } from '@/context/language-context';
import { translations } from '@/lib/translations';


const NavItems = () => {
    const pathname = usePathname();
    const { language } = useLanguage();
    const t = translations[language];

    const navItems = [
      { href: '/dashboard', icon: LayoutDashboard, label: t.nav.dashboard },
      { href: '/disease-detection', icon: Leaf, label: t.nav.diseaseDetection },
      { href: '/soil-analysis', icon: TestTube2, label: t.nav.soilAnalysis },
    ];

    return (
        <>
            <SidebarMenu>
                {navItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                    <SidebarMenuButton
                    asChild
                    isActive={pathname === item.href}
                    tooltip={item.label}
                    >
                    <Link href={item.href}>
                        <item.icon />
                        <span>{item.label}</span>
                    </Link>
                    </SidebarMenuButton>
                </SidebarMenuItem>
                ))}
            </SidebarMenu>
        </>
    )
}

const Header = () => {
    const pathname = usePathname();
    const { language, setLanguage } = useLanguage();
    const t = translations[language];

    const navItems = [
      { href: '/dashboard', icon: LayoutDashboard, label: t.nav.dashboard },
      { href: '/disease-detection', icon: Leaf, label: t.nav.diseaseDetection },
      { href: '/soil-analysis', icon: TestTube2, label: t.nav.soilAnalysis },
    ];
    
    return (
        <header className="flex h-14 items-center gap-4 border-b bg-background/80 backdrop-blur-sm px-6 sticky top-0 z-30">
            <SidebarTrigger className="md:hidden" />
            <div className='flex-1'>
                <h1 className="text-lg font-semibold">
                    {navItems.find(item => item.href === pathname)?.label || 'Dashboard'}
                </h1>
            </div>
            <Select value={language} onValueChange={(value) => setLanguage(value as 'en' | 'hi' | 'kn')}>
              <SelectTrigger className="w-auto" aria-label="Select language">
                  <div className='flex items-center gap-2'>
                    <Languages className='h-4 w-4' />
                    <SelectValue placeholder="Language" />
                  </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="hi">Hindi</SelectItem>
                <SelectItem value="kn">Kannada</SelectItem>
              </SelectContent>
            </Select>
        </header>
    )
}

function AppLayoutContent({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
          <AppLogo />
        </SidebarHeader>
        <SidebarContent>
          <NavItems />
        </SidebarContent>
      </Sidebar>
      <SidebarInset>
        <Header />
        <main className="flex-1 overflow-auto p-4 md:p-6">
          {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}


export default function AppLayout({ children }: { children: React.ReactNode }) {
    return (
        <LanguageProvider>
            <AppLayoutContent>{children}</AppLayoutContent>
        </LanguageProvider>
    )
}
