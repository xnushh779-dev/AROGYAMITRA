'use client';
import { PageHeader, PageHeaderHeading, PageHeaderDescription } from '@/components/page-header';
import { DiseaseDetectionForm } from './disease-detection-form';
import { useLanguage } from '@/context/language-context';
import { translations } from '@/lib/translations';

export default function DiseaseDetectionPage() {
  const { language } = useLanguage();
  const t = translations[language].diseaseDetection;
  return (
    <div className="container mx-auto">
      <PageHeader>
        <PageHeaderHeading>{t.title}</PageHeaderHeading>
        <PageHeaderDescription>
          {t.description}
        </PageHeaderDescription>
      </PageHeader>
      <DiseaseDetectionForm />
    </div>
  );
}
