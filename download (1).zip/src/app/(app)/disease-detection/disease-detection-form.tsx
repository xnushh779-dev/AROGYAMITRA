'use client';

import { useState, useRef, type ChangeEvent } from 'react';
import Image from 'next/image';
import { BookOpen, Bot, FileUp, Loader2, Sparkles, X } from 'lucide-react';
import { diagnosePlantDiseaseFromImage } from '@/ai/flows/diagnose-plant-disease-from-image';
import { accessDiseaseInformation } from '@/ai/flows/access-disease-information-tool';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLanguage } from '@/context/language-context';
import { translations } from '@/lib/translations';

type DiagnosisResult = {
  diseaseDiagnosis: string;
};

type DiseaseInfoResult = {
  diseaseInformation: string;
};

export function DiseaseDetectionForm() {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [diagnosis, setDiagnosis] = useState<DiagnosisResult | null>(null);
  const [diseaseInfo, setDiseaseInfo] = useState<DiseaseInfoResult | null>(null);
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [isFetchingInfo, setIsFetchingInfo] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { language } = useLanguage();
  const t = translations[language].diseaseDetectionForm;

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      if (!selectedFile.type.startsWith('image/')) {
        toast({
          title: t.toast.invalidFileType.title,
          description: t.toast.invalidFileType.description,
          variant: 'destructive',
        });
        return;
      }
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
      setDiagnosis(null);
      setDiseaseInfo(null);
    }
  };

  const handleDiagnose = async () => {
    if (!file || !previewUrl) {
      toast({
        title: t.toast.noImageSelected.title,
        description: t.toast.noImageSelected.description,
        variant: 'destructive',
      });
      return;
    }
    
    setIsDiagnosing(true);
    setDiagnosis(null);
    setDiseaseInfo(null);
    
    try {
      const result = await diagnosePlantDiseaseFromImage({ photoDataUri: previewUrl });
      setDiagnosis(result);
    } catch (error) {
      console.error(error);
      toast({
        title: t.toast.diagnosisFailed.title,
        description: t.toast.diagnosisFailed.description,
        variant: 'destructive',
      });
    } finally {
      setIsDiagnosing(false);
    }
  };
  
  const handleLearnMore = async () => {
    if (!diagnosis?.diseaseDiagnosis) return;
    
    setIsFetchingInfo(true);
    setDiseaseInfo(null);
    try {
      const result = await accessDiseaseInformation({ diseaseName: diagnosis.diseaseDiagnosis });
      setDiseaseInfo(result);
    } catch (error) {
      console.error(error);
      toast({
        title: t.toast.fetchFailed.title,
        description: t.toast.fetchFailed.description,
        variant: 'destructive',
      });
    } finally {
      setIsFetchingInfo(false);
    }
  }

  const clearSelection = () => {
    setFile(null);
    setPreviewUrl(null);
    setDiagnosis(null);
    setDiseaseInfo(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="grid gap-8 md:grid-cols-2">
      <Card className="flex flex-col">
        <CardHeader>
          <CardTitle className='flex items-center gap-2'><FileUp /> {t.uploadCard.title}</CardTitle>
        </CardHeader>
        <CardContent className="flex-grow flex flex-col items-center justify-center p-4">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
          />
          {previewUrl ? (
            <div className="relative w-full max-w-sm aspect-square group">
              <Image src={previewUrl} alt={t.uploadCard.imageAlt} fill className="rounded-lg object-contain" />
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={clearSelection}
              >
                <X className="h-4 w-4" />
                <span className="sr-only">{t.uploadCard.clearSelection}</span>
              </Button>
            </div>
          ) : (
            <div
              className="w-full min-h-[300px] flex-grow flex items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/30 hover:border-primary hover:bg-accent/20 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
              onKeyDown={(e) => { if (e.key === 'Enter') fileInputRef.current?.click(); }}
              tabIndex={0}
              role="button"
              aria-label={t.uploadCard.ariaLabel}
            >
              <div className="text-center text-muted-foreground">
                <FileUp className="mx-auto h-12 w-12" />
                <p className="mt-2">{t.uploadCard.instruction}</p>
                <p className="text-xs">{t.uploadCard.fileTypes}</p>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter>
            <Button onClick={handleDiagnose} disabled={isDiagnosing || !file} className="w-full bg-accent hover:bg-accent/90">
                {isDiagnosing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                {t.diagnoseButton}
            </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Bot /> {t.diagnosisCard.title}</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center min-h-[200px]">
          {isDiagnosing ? (
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p>{t.diagnosisCard.analyzing}</p>
            </div>
          ) : diagnosis ? (
            <div className="text-center">
              <p className="text-muted-foreground">{t.diagnosisCard.diagnosisLabel}:</p>
              <h3 className="text-2xl font-bold text-primary">{diagnosis.diseaseDiagnosis}</h3>
                <Dialog>
                    <DialogTrigger asChild>
                         <Button onClick={handleLearnMore} disabled={isFetchingInfo} variant="outline" className="mt-4">
                            {isFetchingInfo ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <BookOpen className="mr-2 h-4 w-4" />}
                            {t.learnMoreButton}
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                        <DialogHeader>
                            <DialogTitle className='text-2xl'>{diagnosis.diseaseDiagnosis}</DialogTitle>
                            <DialogDescription>{t.dialog.description}</DialogDescription>
                        </DialogHeader>
                        <ScrollArea className="h-[60vh] mt-4">
                            <div className="prose dark:prose-invert max-w-none pr-6">
                                {(isFetchingInfo && !diseaseInfo) ? (
                                    <div className="flex items-center justify-center h-full">
                                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                                    </div>
                                ) : (
                                    <p>{diseaseInfo?.diseaseInformation}</p>
                                )}
                            </div>
                        </ScrollArea>
                    </DialogContent>
                </Dialog>
            </div>
          ) : (
            <p className="text-muted-foreground text-center">{t.diagnosisCard.placeholder}</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
