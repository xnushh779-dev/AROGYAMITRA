'use client';
import { PageHeader, PageHeaderHeading, PageHeaderDescription } from '@/components/page-header';
import { SoilAnalysisForms } from './soil-analysis-forms';
import { useLanguage } from '@/context/language-context';
import { translations } from '@/lib/translations';

export default function SoilAnalysisPage() {
  const { language } = useLanguage();
  const t = translations[language].soilAnalysis;
  return (
    <div className="container mx-auto">
      <PageHeader>
        <PageHeaderHeading>{t.title}</PageHeaderHeading>
        <PageHeaderDescription>
          {t.description}
        </PageHeaderDescription>
      </PageHeader>
      <SoilAnalysisForms />
    </div>
  );
}
