'use client';

import { useState } from 'react';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Bot, FlaskConical, Loader2, Sparkles, Droplets } from 'lucide-react';
import { predictSoilType } from '@/ai/flows/predict-soil-type';
import { getFertilizerRecommendations } from '@/ai/flows/get-fertilizer-recommendations';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useLanguage } from '@/context/language-context';
import { translations } from '@/lib/translations';

const soilTypeSchema = z.object({
  soilDescription: z.string().min(20, { message: 'Please provide a more detailed description (at least 20 characters).' }),
});
type SoilTypeFormData = z.infer<typeof soilTypeSchema>;

const fertilizerSchema = z.object({
  soilAnalysis: z.string().min(20, { message: 'Please provide detailed soil analysis (at least 20 characters).' }),
  cropData: z.string().min(10, { message: 'Please provide crop data (at least 10 characters).' }),
});
type FertilizerFormData = z.infer<typeof fertilizerSchema>;

type SoilTypeResult = {
  soilType: string;
  confidence: number;
};
type FertilizerResult = {
  recommendations: string;
};

export function SoilAnalysisForms() {
  const [activeTab, setActiveTab] = useState('soil-type');
  const [isPredictingSoil, setIsPredictingSoil] = useState(false);
  const [isRecommending, setIsRecommending] = useState(false);
  const [soilTypeResult, setSoilTypeResult] = useState<SoilTypeResult | null>(null);
  const [fertilizerResult, setFertilizerResult] = useState<FertilizerResult | null>(null);
  const { toast } = useToast();
  const { language } = useLanguage();
  const t = translations[language].soilAnalysisForms;

  const soilTypeForm = useForm<SoilTypeFormData>({
    resolver: zodResolver(soilTypeSchema),
    defaultValues: { soilDescription: '' },
  });

  const fertilizerForm = useForm<FertilizerFormData>({
    resolver: zodResolver(fertilizerSchema),
    defaultValues: { soilAnalysis: '', cropData: '' },
  });

  const onSoilTypeSubmit: SubmitHandler<SoilTypeFormData> = async (data) => {
    setIsPredictingSoil(true);
    setSoilTypeResult(null);
    try {
      const result = await predictSoilType(data);
      setSoilTypeResult(result);
    } catch (error) {
      toast({ title: t.toast.predictionFailed.title, description: t.toast.predictionFailed.description, variant: 'destructive' });
    } finally {
      setIsPredictingSoil(false);
    }
  };

  const onFertilizerSubmit: SubmitHandler<FertilizerFormData> = async (data) => {
    setIsRecommending(true);
    setFertilizerResult(null);
    try {
      const result = await getFertilizerRecommendations(data);
      setFertilizerResult(result);
    } catch (error) {
      toast({ title: t.toast.recommendationFailed.title, description: t.toast.recommendationFailed.description, variant: 'destructive' });
    } finally {
      setIsRecommending(false);
    }
  };

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="soil-type">{t.tabs.soilType}</TabsTrigger>
        <TabsTrigger value="fertilizer">{t.tabs.fertilizer}</TabsTrigger>
      </TabsList>
      <TabsContent value="soil-type">
        <Card>
          <Form {...soilTypeForm}>
            <form onSubmit={soilTypeForm.handleSubmit(onSoilTypeSubmit)}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><FlaskConical /> {t.soilType.title}</CardTitle>
                <CardDescription>{t.soilType.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <FormField
                  control={soilTypeForm.control}
                  name="soilDescription"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.soilType.form.label}</FormLabel>
                      <FormControl>
                        <Textarea placeholder={t.soilType.form.placeholder} {...field} rows={6} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
              <CardFooter className="flex-col items-start gap-4">
                <Button type="submit" disabled={isPredictingSoil}>
                  {isPredictingSoil ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                  {t.soilType.buttonText}
                </Button>
                {isPredictingSoil && <p className="text-sm text-muted-foreground">{t.soilType.analyzingText}</p>}
                {soilTypeResult && (
                  <Card className="w-full bg-accent/10">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2"><Bot /> {t.soilType.result.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{t.soilType.result.soilTypeLabel}</p>
                        <p className="text-xl font-bold text-primary">{soilTypeResult.soilType}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{t.soilType.result.confidenceLabel}</p>
                        <div className="flex items-center gap-2">
                            <Progress value={soilTypeResult.confidence * 100} className="w-[80%]" />
                            <span className="font-mono text-sm font-semibold text-primary">{(soilTypeResult.confidence * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardFooter>
            </form>
          </Form>
        </Card>
      </TabsContent>
      <TabsContent value="fertilizer">
        <Card>
          <Form {...fertilizerForm}>
            <form onSubmit={fertilizerForm.handleSubmit(onFertilizerSubmit)}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Droplets /> {t.fertilizer.title}</CardTitle>
                <CardDescription>{t.fertilizer.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={fertilizerForm.control}
                  name="soilAnalysis"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.fertilizer.form.soilAnalysis.label}</FormLabel>
                      <FormControl>
                        <Textarea placeholder={t.fertilizer.form.soilAnalysis.placeholder} {...field} rows={4} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={fertilizerForm.control}
                  name="cropData"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.fertilizer.form.cropData.label}</FormLabel>
                      <FormControl>
                        <Textarea placeholder={t.fertilizer.form.cropData.placeholder} {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
              <CardFooter className="flex-col items-start gap-4">
                <Button type="submit" disabled={isRecommending}>
                  {isRecommending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                  {t.fertilizer.buttonText}
                </Button>
                {isRecommending && <p className="text-sm text-muted-foreground">{t.fertilizer.calculatingText}</p>}
                {fertilizerResult && (
                   <Card className="w-full bg-accent/10">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2"><Bot /> {t.fertilizer.result.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="whitespace-pre-wrap">{fertilizerResult.recommendations}</p>
                    </CardContent>
                  </Card>
                )}
              </CardFooter>
            </form>
          </Form>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
