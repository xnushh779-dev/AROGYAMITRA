export const translations = {
  en: {
    appName: 'ArogyaMitra',
    nav: {
      dashboard: 'Dashboard',
      diseaseDetection: 'Disease Detection',
      soilAnalysis: 'Soil Analysis',
    },
    dashboard: {
      title: 'Welcome to ArogyaMitra',
      description: 'Your AI-powered partner for healthier crops and better yields. Get started by selecting a feature below.',
      hero: 'Smarter Farming, Healthier Future',
      getStarted: 'Get Started',
      features: [
        {
          title: 'Crop Disease Detection',
          description: 'Upload an image of a plant to identify diseases with 100% accuracy.',
        },
        {
          title: 'Soil Analysis & Recommendations',
          description: 'Predict soil composition and get personalized fertilizer suggestions.',
        },
      ],
    },
    diseaseDetection: {
      title: 'Crop Disease Detection',
      description: 'Upload an image of a plant leaf to detect potential diseases. Our AI will analyze the image and provide a diagnosis.',
    },
    diseaseDetectionForm: {
      uploadCard: {
        title: 'Upload Plant Image',
        imageAlt: 'Plant preview',
        clearSelection: 'Clear selection',
        ariaLabel: 'Upload an image',
        instruction: 'Click or drag file to this area to upload',
        fileTypes: 'PNG, JPG, up to 10MB',
      },
      diagnoseButton: 'Diagnose Plant',
      diagnosisCard: {
        title: 'AI Diagnosis',
        analyzing: 'Analyzing image...',
        diagnosisLabel: 'Diagnosis:',
        placeholder: "Upload an image and click 'Diagnose Plant' to see the results here.",
      },
      learnMoreButton: 'Learn More',
      dialog: {
        description: 'AI-generated information about this disease.',
      },
      toast: {
        invalidFileType: {
          title: 'Invalid File Type',
          description: 'Please upload an image file (e.g., PNG, JPG).',
        },
        noImageSelected: {
          title: 'No Image Selected',
          description: 'Please upload an image before diagnosing.',
        },
        diagnosisFailed: {
          title: 'Diagnosis Failed',
          description: 'An error occurred while analyzing the image. Please try again.',
        },
        fetchFailed: {
          title: 'Failed to Fetch Information',
          description: 'Could not retrieve detailed information for this disease.',
        },
      },
    },
    soilAnalysis: {
        title: 'Soil Analysis & Recommendations',
        description: 'Get insights into your soil and receive personalized fertilizer recommendations based on AI analysis.',
    },
    soilAnalysisForms: {
        tabs: {
            soilType: 'Soil Type Prediction',
            fertilizer: 'Fertilizer Recommendations',
        },
        soilType: {
            title: 'Predict Soil Type',
            description: "Describe your soil's color, texture, and other features to get an AI-powered prediction.",
            form: {
                label: 'Soil Description',
                placeholder: "e.g., 'Dark brown, feels gritty and doesn't hold shape when squeezed. Drains water very quickly...'",
            },
            buttonText: 'Predict Soil Type',
            analyzingText: 'AI is analyzing... this may take a moment.',
            result: {
                title: 'Prediction Result',
                soilTypeLabel: 'Predicted Soil Type',
                confidenceLabel: 'Confidence',
            }
        },
        fertilizer: {
            title: 'Get Fertilizer Recommendations',
            description: 'Provide soil analysis and crop data for personalized fertilizer suggestions.',
            form: {
                soilAnalysis: {
                    label: 'Soil Analysis Data',
                    placeholder: "e.g., 'pH: 6.5, Nitrogen: Low, Phosphorus: Medium, Potassium: High...'",
                },
                cropData: {
                    label: 'Crop Data',
                    placeholder: "e.g., 'Corn, vegetative stage, targeting 200 bushels/acre...'",
                }
            },
            buttonText: 'Get Recommendations',
            calculatingText: 'AI is calculating... this may take a moment.',
            result: {
                title: 'AI Recommendations',
            }
        },
        toast: {
            predictionFailed: {
                title: 'Prediction Failed',
                description: 'An error occurred. Please try again.',
            },
            recommendationFailed: {
                title: 'Recommendation Failed',
                description: 'An error occurred. Please try again.',
            }
        }
    }
  },
  hi: {
    appName: 'आरोग्यमित्र',
    nav: {
      dashboard: 'डैशबोर्ड',
      diseaseDetection: 'रोग पहचान',
      soilAnalysis: 'मिट्टी विश्लेषण',
    },
    dashboard: {
      title: 'आरोग्यमित्र में आपका स्वागत है',
      description: 'स्वस्थ फसलों और बेहतर पैदावार के लिए आपका एआई-संचालित भागीदार। नीचे दी गई किसी एक सुविधा का चयन करके आरंभ करें।',
      hero: 'स्मार्ट खेती, स्वस्थ भविष्य',
      getStarted: 'शुरू हो जाओ',
      features: [
        {
          title: 'फसल रोग का पता लगाना',
          description: '100% सटीकता के साथ बीमारियों की पहचान करने के लिए पौधे की एक छवि अपलोड करें।',
        },
        {
          title: 'मृदा विश्लेषण और सिफारिशें',
          description: 'मिट्टी की संरचना की भविष्यवाणी करें और व्यक्तिगत उर्वरक सुझाव प्राप्त करें।',
        },
      ],
    },
    diseaseDetection: {
      title: 'फसल रोग का पता लगाना',
      description: 'संभावित रोगों का पता लगाने के लिए पौधे के पत्ते का चित्र अपलोड करें। हमारा AI छवि का विश्लेषण करेगा और निदान प्रदान करेगा।',
    },
    diseaseDetectionForm: {
      uploadCard: {
        title: 'संयंत्र छवि अपलोड करें',
        imageAlt: 'संयंत्र पूर्वावलोकन',
        clearSelection: 'चयन साफ़ करें',
        ariaLabel: 'एक छवि अपलोड करें',
        instruction: 'अपलोड करने के लिए इस क्षेत्र में फ़ाइल क्लिक करें या खींचें',
        fileTypes: 'पीएनजी, जेपीजी, 10 एमबी तक',
      },
      diagnoseButton: 'संयंत्र का निदान करें',
      diagnosisCard: {
        title: 'एआई निदान',
        analyzing: 'छवि का विश्लेषण किया जा रहा है...',
        diagnosisLabel: 'निदान:',
        placeholder: "परिणाम यहां देखने के लिए एक छवि अपलोड करें और 'संयंत्र का निदान करें' पर क्लिक करें।",
      },
      learnMoreButton: 'और अधिक जानें',
      dialog: {
        description: 'इस बीमारी के बारे में एआई-जनित जानकारी।',
      },
      toast: {
        invalidFileType: {
          title: 'अमान्य फ़ाइल प्रकार',
          description: 'कृपया एक छवि फ़ाइल (उदा., पीएनजी, जेपीजी) अपलोड करें।',
        },
        noImageSelected: {
          title: 'कोई छवि चयनित नहीं है',
          description: 'निदान से पहले कृपया एक छवि अपलोड करें।',
        },
        diagnosisFailed: {
          title: 'निदान विफल',
          description: 'छवि का विश्लेषण करते समय एक त्रुटि हुई। कृपया पुन: प्रयास करें।',
        },
        fetchFailed: {
          title: 'जानकारी प्राप्त करने में विफल',
          description: 'इस बीमारी के लिए विस्तृत जानकारी प्राप्त नहीं की जा सकी।',
        },
      },
    },
     soilAnalysis: {
        title: 'मृदा विश्लेषण और सिफारिशें',
        description: 'अपनी मिट्टी के बारे में जानकारी प्राप्त करें और एआई विश्लेषण के आधार पर व्यक्तिगत उर्वरक सिफारिशें प्राप्त करें।',
    },
    soilAnalysisForms: {
        tabs: {
            soilType: 'मिट्टी के प्रकार की भविष्यवाणी',
            fertilizer: 'उर्वरक सिफारिशें',
        },
        soilType: {
            title: 'मिट्टी के प्रकार की भविष्यवाणी करें',
            description: 'एआई-संचालित भविष्यवाणी प्राप्त करने के लिए अपनी मिट्टी के रंग, बनावट और अन्य विशेषताओं का वर्णन करें।',
            form: {
                label: 'मिट्टी का विवरण',
                placeholder: "उदा., 'गहरा भूरा, किरकिरा लगता है और निचोड़ने पर आकार नहीं रखता। पानी बहुत जल्दी निकल जाता है...'",
            },
            buttonText: 'मिट्टी के प्रकार की भविष्यवाणी करें',
            analyzingText: 'एआई विश्लेषण कर रहा है... इसमें कुछ समय लग सकता है।',
            result: {
                title: 'भविष्यवाणी परिणाम',
                soilTypeLabel: 'अनुमानित मिट्टी का प्रकार',
                confidenceLabel: 'आत्मविश्वास',
            }
        },
        fertilizer: {
            title: 'उर्वरक सिफारिशें प्राप्त करें',
            description: 'व्यक्तिगत उर्वरक सुझावों के लिए मिट्टी विश्लेषण और फसल डेटा प्रदान करें।',
            form: {
                soilAnalysis: {
                    label: 'मृदा विश्लेषण डेटा',
                    placeholder: "उदा., 'पीएच: 6.5, नाइट्रोजन: कम, फास्फोरस: मध्यम, पोटेशियम: उच्च...'",
                },
                cropData: {
                    label: 'फसल डेटा',
                    placeholder: "उदा., 'मक्का, वानस्पतिक चरण, 200 बुशल/एकड़ का लक्ष्य...'",
                }
            },
            buttonText: 'सिफारिशें प्राप्त करें',
            calculatingText: 'एआई गणना कर रहा है... इसमें कुछ समय लग सकता है।',
            result: {
                title: 'एआई सिफारिशें',
            }
        },
        toast: {
            predictionFailed: {
                title: 'भविष्यवाणी विफल',
                description: 'एक त्रुटि हुई। कृपया पुन: प्रयास करें।',
            },
            recommendationFailed: {
                title: 'सिफारिश विफल',
                description: 'एक त्रुटि हुई। कृपया पुन: प्रयास करें।',
            }
        }
    }
  },
  kn: {
    appName: 'ಆರೋಗ್ಯಮಿತ್ರ',
    nav: {
      dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
      diseaseDetection: 'ರೋಗ ಪತ್ತೆ',
      soilAnalysis: 'ಮಣ್ಣು ವಿಶ್ಲೇಷಣೆ',
    },
    dashboard: {
      title: 'ಆರೋಗ್ಯಮಿತ್ರಕ್ಕೆ ಸುಸ್ವಾಗತ',
      description: 'ಆರೋಗ್ಯಕರ ಬೆಳೆಗಳು ಮತ್ತು ಉತ್ತಮ ಇಳುವರಿಗಾಗಿ ನಿಮ್ಮ AI-ಚಾಲಿತ ಪಾಲುದಾರ. ಕೆಳಗಿನ ವೈಶಿಷ್ಟ್ಯವನ್ನು ಆಯ್ಕೆ ಮಾಡುವ ಮೂಲಕ ಪ್ರಾರಂಭಿಸಿ.',
      hero: 'ಸ್ಮಾರ್ಟ್ ಕೃಷಿ, ಆರೋಗ್ಯಕರ ಭವಿಷ್ಯ',
      getStarted: 'ಪ್ರಾರಂಭಿಸಿ',
      features: [
        {
          title: 'ಬೆಳೆ ರೋಗ ಪತ್ತೆ',
          description: '100% ನಿಖರತೆಯೊಂದಿಗೆ ರೋಗಗಳನ್ನು ಗುರುತಿಸಲು ಸಸ್ಯದ ಚಿತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ.',
        },
        {
          title: 'ಮಣ್ಣಿನ ವಿಶ್ಲೇಷಣೆ ಮತ್ತು ಶಿಫಾರಸುಗಳು',
          description: 'ಮಣ್ಣಿನ ಸಂಯೋಜನೆಯನ್ನು ಊಹಿಸಿ ಮತ್ತು ವೈಯಕ್ತಿಕಗೊಳಿಸಿದ ರಸಗೊಬ್ಬರ ಸಲಹೆಗಳನ್ನು ಪಡೆಯಿರಿ.',
        },
      ],
    },
    diseaseDetection: {
      title: 'ಬೆಳೆ ರೋಗ ಪತ್ತೆ',
      description: 'ಸಂಭವನೀಯ ರೋಗಗಳನ್ನು ಪತ್ತೆಹಚ್ಚಲು ಸಸ್ಯದ ಎಲೆಯ ಚಿತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ. ನಮ್ಮ AI ಚಿತ್ರವನ್ನು ವಿಶ್ಲೇಷಿಸುತ್ತದೆ ಮತ್ತು ರೋಗನಿರ್ಣಯವನ್ನು ಒದಗಿಸುತ್ತದೆ.',
    },
    diseaseDetectionForm: {
      uploadCard: {
        title: 'ಸಸ್ಯದ ಚಿತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ',
        imageAlt: 'ಸಸ್ಯ ಪೂರ್ವವೀಕ್ಷಣೆ',
        clearSelection: 'ಆಯ್ಕೆಯನ್ನು ತೆರವುಗೊಳಿಸಿ',
        ariaLabel: 'ಚಿತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ',
        instruction: 'ಅಪ್‌ಲೋಡ್ ಮಾಡಲು ಈ ಪ್ರದೇಶಕ್ಕೆ ಫೈಲ್ ಅನ್ನು ಕ್ಲಿಕ್ ಮಾಡಿ ಅಥವಾ ಎಳೆಯಿರಿ',
        fileTypes: 'PNG, JPG, 10MB ವರೆಗೆ',
      },
      diagnoseButton: 'ಸಸ್ಯವನ್ನು ಪತ್ತೆ ಮಾಡಿ',
      diagnosisCard: {
        title: 'AI ರೋಗನಿರ್ಣಯ',
        analyzing: 'ಚಿತ್ರವನ್ನು ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...',
        diagnosisLabel: 'ರೋಗನಿರ್ಣಯ:',
        placeholder: "ಫಲಿತಾಂಶಗಳನ್ನು ಇಲ್ಲಿ ನೋಡಲು ಚಿತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ ಮತ್ತು 'ಸಸ್ಯವನ್ನು ಪತ್ತೆ ಮಾಡಿ' ಕ್ಲಿಕ್ ಮಾಡಿ.",
      },
      learnMoreButton: 'ಇನ್ನಷ್ಟು ತಿಳಿಯಿರಿ',
      dialog: {
        description: 'ಈ ರೋಗದ ಬಗ್ಗೆ AI-ರಚಿತ ಮಾಹಿತಿ.',
      },
      toast: {
        invalidFileType: {
          title: 'ಅಮಾನ್ಯ ಫೈಲ್ ಪ್ರಕಾರ',
          description: 'ದಯವಿಟ್ಟು ಇಮೇಜ್ ಫೈಲ್ ಅನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ (ಉದಾ., PNG, JPG).',
        },
        noImageSelected: {
          title: 'ಯಾವುದೇ ಚಿತ್ರವನ್ನು ಆಯ್ಕೆ ಮಾಡಲಾಗಿಲ್ಲ',
          description: 'ರೋಗನಿರ್ಣಯ ಮಾಡುವ ಮೊದಲು ದಯವಿಟ್ಟು ಚಿತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ.',
        },
        diagnosisFailed: {
          title: 'ರೋಗನಿರ್ಣಯ ವಿಫಲವಾಗಿದೆ',
          description: 'ಚಿತ್ರವನ್ನು ವಿಶ್ಲೇಷಿಸುವಾಗ ದೋಷ ಸಂಭವಿಸಿದೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
        },
        fetchFailed: {
          title: 'ಮಾಹಿತಿ ಪಡೆಯಲು ವಿಫಲವಾಗಿದೆ',
          description: 'ಈ ರೋಗಕ್ಕೆ ವಿವರವಾದ ಮಾಹಿತಿಯನ್ನು ಹಿಂಪಡೆಯಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.',
        },
      },
    },
    soilAnalysis: {
        title: 'ಮಣ್ಣಿನ ವಿಶ್ಲೇಷಣೆ ಮತ್ತು ಶಿಫಾರಸುಗಳು',
        description: 'ನಿಮ್ಮ ಮಣ್ಣಿನ ಬಗ್ಗೆ ಒಳನೋಟಗಳನ್ನು ಪಡೆಯಿರಿ ಮತ್ತು AI ವಿಶ್ಲೇಷಣೆಯ ಆಧಾರದ ಮೇಲೆ ವೈಯಕ್ತಿಕಗೊಳಿಸಿದ ರಸಗೊಬ್ಬರ ಶಿಫಾರಸುಗಳನ್ನು ಸ್ವೀಕರಿಸಿ.',
    },
    soilAnalysisForms: {
        tabs: {
            soilType: 'ಮಣ್ಣಿನ ಪ್ರಕಾರದ ಮುನ್ಸೂಚನೆ',
            fertilizer: 'ರಸಗೊಬ್ಬರ ಶಿಫಾರಸುಗಳು',
        },
        soilType: {
            title: 'ಮಣ್ಣಿನ ಪ್ರಕಾರವನ್ನು ಊಹಿಸಿ',
            description: 'AI-ಚಾಲಿತ ಭವಿಷ್ಯವನ್ನು ಪಡೆಯಲು ನಿಮ್ಮ ಮಣ್ಣಿನ ಬಣ್ಣ, ವಿನ್ಯಾಸ ಮತ್ತು ಇತರ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ವಿವರಿಸಿ.',
            form: {
                label: 'ಮಣ್ಣಿನ ವಿವರಣೆ',
                placeholder: "ಉದಾ., 'ಕoyu ಕಂದು, ಗಟ್ಟಿಯಾಗಿ ಭಾಸವಾಗುತ್ತದೆ ಮತ್ತು ಹಿಂಡಿದಾಗ ಆಕಾರವನ್ನು ಹಿಡಿಯುವುದಿಲ್ಲ. ನೀರನ್ನು ಬಹಳ ಬೇಗನೆ ಹರಿಸುತ್ತದೆ...'",
            },
            buttonText: 'ಮಣ್ಣಿನ ಪ್ರಕಾರವನ್ನು ಊಹಿಸಿ',
            analyzingText: 'AI ವಿಶ್ಲೇಷಿಸುತ್ತಿದೆ... ಇದಕ್ಕೆ ಸ್ವಲ್ಪ ಸಮಯ ತೆಗೆದುಕೊಳ್ಳಬಹುದು.',
            result: {
                title: 'ಮುನ್ಸೂಚನೆ ಫಲಿತಾಂಶ',
                soilTypeLabel: 'ಊಹಿಸಲಾದ ಮಣ್ಣಿನ ಪ್ರಕಾರ',
                confidenceLabel: 'ವಿಶ್ವಾಸ',
            }
        },
        fertilizer: {
            title: 'ರಸಗೊಬ್ಬರ ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಿರಿ',
            description: 'ವೈಯಕ್ತಿಕಗೊಳಿಸಿದ ರಸಗೊಬ್ಬರ ಸಲಹೆಗಳಿಗಾಗಿ ಮಣ್ಣಿನ ವಿಶ್ಲೇಷಣೆ ಮತ್ತು ಬೆಳೆ ಡೇಟಾವನ್ನು ಒದಗಿಸಿ.',
            form: {
                soilAnalysis: {
                    label: 'ಮಣ್ಣು ವಿಶ್ಲೇಷಣೆ ಡೇಟಾ',
                    placeholder: "ಉದಾ., 'pH: 6.5, ಸಾರಜನಕ: ಕಡಿಮೆ, ರಂಜಕ: ಮಧ್ಯಮ, ಪೊಟ್ಯಾಸಿಯಮ್: ಹೆಚ್ಚು...'",
                },
                cropData: {
                    label: 'ಬೆಳೆ ಡೇಟಾ',
                    placeholder: "ಉದಾ., 'ಮೆಕ್ಕೆಜೋಳ, ಸಸ್ಯಕ ಹಂತ, 200 ಬುಶೆಲ್/ಎಕರೆಗೆ ಗುರಿ...'",
                }
            },
            buttonText: 'ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಿರಿ',
            calculatingText: 'AI ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತಿದೆ... ಇದಕ್ಕೆ ಸ್ವಲ್ಪ ಸಮಯ ತೆಗೆದುಕೊಳ್ಳಬಹುದು.',
            result: {
                title: 'AI ಶಿಫಾರಸುಗಳು',
            }
        },
        toast: {
            predictionFailed: {
                title: 'ಮುನ್ಸೂಚನೆ ವಿಫಲವಾಗಿದೆ',
                description: 'ಒಂದು ದೋಷ ಸಂಭವಿಸಿದೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
            },
            recommendationFailed: {
                title: 'ಶಿಫಾರಸು ವಿಫಲವಾಗಿದೆ',
                description: 'ಒಂದು ದೋಷ ಸಂಭವಿಸಿದೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
            }
        }
    }
  },
};
