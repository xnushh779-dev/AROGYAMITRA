'use client';
import { Sprout } from "lucide-react";
import { useLanguage } from "@/context/language-context";
import { translations } from "@/lib/translations";

export function AppLogo() {
  const { language } = useLanguage();
  const t = translations[language];
  return (
    <div className="flex items-center gap-2 text-lg font-bold tracking-tight text-primary">
      <Sprout className="h-6 w-6" />
      <span>{t.appName}</span>
    </div>
  );
}
