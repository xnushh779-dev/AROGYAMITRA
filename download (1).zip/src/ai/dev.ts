import { config } from 'dotenv';
config();

import '@/ai/flows/diagnose-plant-disease-from-image.ts';
import '@/ai/flows/predict-soil-type.ts';
import '@/ai/flows/access-disease-information-tool.ts';
import '@/ai/flows/get-fertilizer-recommendations.ts';