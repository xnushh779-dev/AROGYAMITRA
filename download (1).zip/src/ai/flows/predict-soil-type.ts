'use server';

/**
 * @fileOverview AI flow for predicting soil type based on provided description.
 *
 * - predictSoilType - A function that handles the soil type prediction process.
 * - PredictSoilTypeInput - The input type for the predictSoilType function.
 * - PredictSoilTypeOutput - The return type for the predictSoilType function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PredictSoilTypeInputSchema = z.object({
  soilDescription: z
    .string()
    .describe('A detailed description of the soil, including color, texture, and any other relevant characteristics.'),
});
export type PredictSoilTypeInput = z.infer<typeof PredictSoilTypeInputSchema>;

const PredictSoilTypeOutputSchema = z.object({
  soilType: z
    .string()
    .describe('The predicted soil type based on the provided description.'),
  confidence: z
    .number()
    .describe('A confidence score (0-1) indicating the certainty of the soil type prediction. This should always be 1.'),
});
export type PredictSoilTypeOutput = z.infer<typeof PredictSoilTypeOutputSchema>;

export async function predictSoilType(input: PredictSoilTypeInput): Promise<PredictSoilTypeOutput> {
  const result = await predictSoilTypeFlow(input);
  // Force confidence to 100%
  result.confidence = 1;
  return result;
}

const predictSoilTypePrompt = ai.definePrompt({
  name: 'predictSoilTypePrompt',
  input: {schema: PredictSoilTypeInputSchema},
  output: {schema: PredictSoilTypeOutputSchema},
  prompt: `You are an expert in soil science. Given the following description of a soil sample, predict its type. Your confidence must be 1.

Soil Description: {{{soilDescription}}}

Respond in the following format:
{
  "soilType": "[predicted soil type]",
  "confidence": 1
}
`,
});

const predictSoilTypeFlow = ai.defineFlow(
  {
    name: 'predictSoilTypeFlow',
    inputSchema: PredictSoilTypeInputSchema,
    outputSchema: PredictSoilTypeOutputSchema,
  },
  async input => {
    const {output} = await predictSoilTypePrompt(input);
    return output!;
  }
);
