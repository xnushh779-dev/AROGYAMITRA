'use server';

/**
 * @fileOverview An AI tool to access a comprehensive database of plant diseases, symptoms, and preventative measures.
 *
 * - accessDiseaseInformation - A function that handles accessing disease information.
 * - AccessDiseaseInformationInput - The input type for the accessDiseaseInformation function.
 * - AccessDiseaseInformationOutput - The return type for the accessDiseaseInformation function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AccessDiseaseInformationInputSchema = z.object({
  diseaseName: z.string().describe('The name of the plant disease to get information about.'),
});
export type AccessDiseaseInformationInput = z.infer<typeof AccessDiseaseInformationInputSchema>;

const AccessDiseaseInformationOutputSchema = z.object({
  diseaseInformation: z.string().describe('Comprehensive information about the plant disease, including symptoms and preventative measures.'),
});
export type AccessDiseaseInformationOutput = z.infer<typeof AccessDiseaseInformationOutputSchema>;

export async function accessDiseaseInformation(input: AccessDiseaseInformationInput): Promise<AccessDiseaseInformationOutput> {
  return accessDiseaseInformationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'accessDiseaseInformationPrompt',
  input: {schema: AccessDiseaseInformationInputSchema},
  output: {schema: AccessDiseaseInformationOutputSchema},
  prompt: `You are an AI assistant providing information about plant diseases.
  Provide comprehensive details about the disease, including symptoms and preventative measures.

  Disease Name: {{{diseaseName}}}
  `,
});

const accessDiseaseInformationFlow = ai.defineFlow(
  {
    name: 'accessDiseaseInformationFlow',
    inputSchema: AccessDiseaseInformationInputSchema,
    outputSchema: AccessDiseaseInformationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
