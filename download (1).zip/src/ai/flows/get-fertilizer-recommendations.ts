'use server';

/**
 * @fileOverview This file defines a Genkit flow for providing personalized fertilizer recommendations based on soil analysis and crop data.
 *
 * - getFertilizerRecommendations - A function that takes soil analysis and crop data as input and returns fertilizer recommendations.
 * - GetFertilizerRecommendationsInput - The input type for the getFertilizerRecommendations function.
 * - GetFertilizerRecommendationsOutput - The return type for the getFertilizerRecommendations function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GetFertilizerRecommendationsInputSchema = z.object({
  soilAnalysis: z
    .string()
    .describe('The analysis of the soil, including nutrient levels and pH.'),
  cropData: z.string().describe('Data about the crop being grown, including type, growth stage, and yield goals.'),
});
export type GetFertilizerRecommendationsInput = z.infer<typeof GetFertilizerRecommendationsInputSchema>;

const GetFertilizerRecommendationsOutputSchema = z.object({
  recommendations: z.string().describe('Personalized fertilizer recommendations based on the soil analysis and crop data.'),
});
export type GetFertilizerRecommendationsOutput = z.infer<typeof GetFertilizerRecommendationsOutputSchema>;

export async function getFertilizerRecommendations(
  input: GetFertilizerRecommendationsInput
): Promise<GetFertilizerRecommendationsOutput> {
  return getFertilizerRecommendationsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'getFertilizerRecommendationsPrompt',
  input: {schema: GetFertilizerRecommendationsInputSchema},
  output: {schema: GetFertilizerRecommendationsOutputSchema},
  prompt: `You are an expert agricultural advisor specializing in fertilizer recommendations.

Based on the following soil analysis and crop data, provide personalized fertilizer recommendations to optimize nutrient use and improve yields.

Soil Analysis: {{{soilAnalysis}}}
Crop Data: {{{cropData}}}

Recommendations:`, // Prompt should request the model to respond with personalized fertilizer recommendations.
});

const getFertilizerRecommendationsFlow = ai.defineFlow(
  {
    name: 'getFertilizerRecommendationsFlow',
    inputSchema: GetFertilizerRecommendationsInputSchema,
    outputSchema: GetFertilizerRecommendationsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
